import java.io.*;
import employee.Emp;
class Emppay
{

 public static void main(String args[])
 {

   Emp e = new Emp("Misba","20","Female",13000);
   e.call();
   e.display();
   }
 }