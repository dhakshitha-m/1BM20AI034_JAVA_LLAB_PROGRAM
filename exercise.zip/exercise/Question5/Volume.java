
public interface Volume
{
   public double getVolume();
}
