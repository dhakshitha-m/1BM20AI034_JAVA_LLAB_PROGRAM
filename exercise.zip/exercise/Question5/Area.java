public interface Area
{
   public double getArea();
}

