
//Pet.java

public interface Pet {
    public String getNaame();
    public void setName(String name);
    public void play();
}
